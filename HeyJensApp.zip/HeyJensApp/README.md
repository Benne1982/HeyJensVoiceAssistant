# Hey Jens Voice Assistant

A voice-activated assistant that listens for the wake phrase "Hey Jens" to launch ChatGPT 4.0 and responds to "Tschüss Jens" to close it.

## Features

- Continuous speech recognition in low-power mode
- Wake phrase detection ("Hey Jens")
- Exit phrase detection ("Tschüss Jens")
- Automatic launch of ChatGPT 4.0
- Energy-efficient background operation
- Automatic restart after system interruptions

## Technical Implementation

### Core Components

1. **VoiceRecognitionService**: A foreground service that continuously listens for the wake phrase
2. **WakewordDetector**: Detects the wake phrase in audio input
3. **JobScheduler Integration**: Ensures the service restarts after system interruptions
4. **WorkManager Integration**: Provides a backup mechanism for service restoration
5. **Battery Optimization**: Requests exemption from battery optimization for reliable operation

### Energy Efficiency

The app is designed to minimize battery usage through:

- Low-priority foreground service
- Optimized audio processing
- Doze mode compatibility
- Efficient wake phrase detection
- ARM64 native optimizations

### Samsung A54G Optimizations

Specifically optimized for Samsung A54G through:

- ARM64-v8a native libraries
- Samsung-specific power management compatibility
- UI optimized for the device's display

## Permissions

The app requires the following permissions:

- `RECORD_AUDIO`: For voice recognition
- `INTERNET`: For ChatGPT communication
- `FOREGROUND_SERVICE`: For continuous operation
- `WAKE_LOCK`: To prevent the CPU from sleeping during critical operations
- `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`: For reliable background operation

## Build Configuration

- **Min SDK**: 24 (Android 7.0)
- **Target SDK**: 33 (Android 13)
- **Kotlin**: Primary development language
- **AndroidX**: Modern Android libraries
- **Material Design 3**: UI components
- **ProGuard**: Optimized for minimal APK size

## Testing

- Unit tests for core functionality
- UI tests for main interactions
- Battery consumption tests
- Compatibility tests across Android versions

## Installation

1. Download the signed APK
2. Install on your Samsung A54G device
3. Grant required permissions
4. Disable battery optimization when prompted
5. Start the service

## Usage

1. Start the service from the app
2. Say "Hey Jens" to launch ChatGPT 4.0
3. Say "Tschüss Jens" to close ChatGPT
4. The service will continue running in the background

## Troubleshooting

- If voice detection stops working, try restarting the service
- Ensure battery optimization is disabled for the app
- Check that microphone permissions are granted
- Verify that ChatGPT is installed on your device

## License

Proprietary - All rights reserved