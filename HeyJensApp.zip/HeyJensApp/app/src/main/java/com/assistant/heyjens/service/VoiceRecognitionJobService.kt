package com.assistant.heyjens.service

import android.app.job.JobParameters
import android.app.job.JobService
import android.content.Intent
import android.os.Build
import android.util.Log

class VoiceRecognitionJobService : JobService() {

    private val TAG = "VoiceRecognitionJobSvc"

    override fun onStartJob(params: JobParameters?): Boolean {
        Log.d(TAG, "Voice recognition job started")
        
        // Check if the service is already running
        if (!VoiceRecognitionService.isRunning) {
            // Start the voice recognition service
            val serviceIntent = Intent(applicationContext, VoiceRecognitionService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                applicationContext.startForegroundService(serviceIntent)
            } else {
                applicationContext.startService(serviceIntent)
            }
        }
        
        // Return false as we've done our work synchronously
        // If you have long-running operations, return true and call jobFinished when done
        return false
    }

    override fun onStopJob(params: JobParameters?): Boolean {
        Log.d(TAG, "Voice recognition job stopped")
        
        // Return true to indicate we want to reschedule this job if it's stopped unexpectedly
        return true
    }
}