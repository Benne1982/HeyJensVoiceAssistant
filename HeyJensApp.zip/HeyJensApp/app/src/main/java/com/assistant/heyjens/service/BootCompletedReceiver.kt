package com.assistant.heyjens.service

import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.work.*
import java.util.concurrent.TimeUnit

class BootCompletedReceiver : BroadcastReceiver() {

    private val TAG = "BootCompletedReceiver"
    private val JOB_ID = 1001

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Log.d(TAG, "Boot completed, scheduling voice recognition service")
            
            // Schedule using JobScheduler for devices running Android 5.0 (API 21) and higher
            scheduleJob(context)
            
            // Also schedule using WorkManager for better compatibility and flexibility
            scheduleWork(context)
        }
    }

    private fun scheduleJob(context: Context) {
        val jobScheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        val componentName = ComponentName(context, VoiceRecognitionJobService::class.java)
        
        val jobInfo = JobInfo.Builder(JOB_ID, componentName)
            .setRequiresCharging(false)
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .setPersisted(true) // Job persists across reboots
            
        // Set different periodic intervals based on Android version
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            // For Android 7.0 (API 24) and higher, minimum is 15 minutes
            jobInfo.setPeriodic(15 * 60 * 1000) // 15 minutes
        } else {
            // For earlier versions, minimum is 1 hour
            jobInfo.setPeriodic(60 * 60 * 1000) // 1 hour
        }
        
        val resultCode = jobScheduler.schedule(jobInfo.build())
        if (resultCode == JobScheduler.RESULT_SUCCESS) {
            Log.d(TAG, "Job scheduled successfully")
        } else {
            Log.e(TAG, "Job scheduling failed")
        }
    }

    private fun scheduleWork(context: Context) {
        // Create a periodic work request that runs every 15 minutes
        val workRequest = PeriodicWorkRequestBuilder<VoiceRecognitionWorker>(15, TimeUnit.MINUTES)
            .setConstraints(
                Constraints.Builder()
                    .setRequiresBatteryNotLow(true)
                    .build()
            )
            .build()
        
        // Enqueue the work with a unique name
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "VoiceRecognitionWork",
            ExistingPeriodicWorkPolicy.REPLACE,
            workRequest
        )
        
        Log.d(TAG, "WorkManager task scheduled")
    }

    // Worker class for WorkManager
    class VoiceRecognitionWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
        override fun doWork(): Result {
            Log.d("VoiceRecognitionWorker", "Starting voice recognition service from worker")
            
            // Start the voice recognition service if it's not running
            if (!VoiceRecognitionService.isRunning) {
                val serviceIntent = Intent(applicationContext, VoiceRecognitionService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    applicationContext.startForegroundService(serviceIntent)
                } else {
                    applicationContext.startService(serviceIntent)
                }
            }
            
            return Result.success()
        }
    }
}