package com.assistant.heyjens.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import com.assistant.heyjens.R
import com.assistant.heyjens.ui.MainActivity
import com.assistant.heyjens.util.WakewordDetector
import kotlinx.coroutines.*
import java.util.*

class VoiceRecognitionService : Service() {

    private val TAG = "VoiceRecognitionService"
    private val NOTIFICATION_ID = 1001
    private val CHANNEL_ID = "VoiceRecognitionChannel"
    
    private var wakeLock: PowerManager.WakeLock? = null
    private var isListening = false
    private var speechRecognizer: SpeechRecognizer? = null
    private var wakewordDetector: WakewordDetector? = null
    private val serviceScope = CoroutineScope(Dispatchers.Default + Job())
    
    companion object {
        var isRunning = false
        private const val WAKEWORD = "hey jens"
        private const val EXIT_PHRASE = "tschüss jens"
        private const val CHATGPT_PACKAGE = "com.openai.chatgpt"
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())
        
        // Initialize wake lock
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "HeyJens::VoiceRecognitionWakeLock"
        ).apply {
            acquire(10*60*1000L /*10 minutes*/)
        }
        
        // Initialize wakeword detector
        wakewordDetector = WakewordDetector(WAKEWORD)
        
        // Start continuous listening
        startContinuousListening()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // If service is killed, restart it
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        stopContinuousListening()
        wakeLock?.release()
        serviceScope.cancel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Voice Recognition Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the voice recognition service running"
                setShowBadge(false)
            }
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Hey Jens Voice Assistant")
            .setContentText("Listening for 'Hey Jens'")
            .setSmallIcon(R.drawable.ic_mic)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun startContinuousListening() {
        if (isListening) return
        
        isListening = true
        
        // Use coroutine for continuous audio processing
        serviceScope.launch {
            val bufferSize = AudioRecord.getMinBufferSize(
                16000,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            
            val audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                16000,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
            
            try {
                audioRecord.startRecording()
                val buffer = ShortArray(bufferSize)
                
                while (isListening && isActive) {
                    val readSize = audioRecord.read(buffer, 0, bufferSize)
                    if (readSize > 0) {
                        // Process audio for wakeword detection
                        val detected = wakewordDetector?.detect(buffer, readSize) ?: false
                        
                        if (detected) {
                            withContext(Dispatchers.Main) {
                                // Wakeword detected, start full speech recognition
                                startSpeechRecognition()
                            }
                            // Pause continuous listening while speech recognition is active
                            delay(5000)
                        }
                    }
                    
                    // Add a small delay to reduce CPU usage
                    delay(100)
                }
            } finally {
                audioRecord.stop()
                audioRecord.release()
            }
        }
    }

    private fun stopContinuousListening() {
        isListening = false
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    private fun startSpeechRecognition() {
        if (speechRecognizer == null) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                // Resume continuous listening after error
                startContinuousListening()
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val text = matches[0].toLowerCase(Locale.getDefault())
                    processRecognizedSpeech(text)
                }
                
                // Resume continuous listening
                startContinuousListening()
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        speechRecognizer?.startListening(recognizerIntent)
    }

    private fun processRecognizedSpeech(text: String) {
        Log.d(TAG, "Recognized: $text")
        
        when {
            text.contains(EXIT_PHRASE) -> {
                // User wants to exit ChatGPT
                stopChatGPT()
            }
            text.contains(WAKEWORD) -> {
                // Launch ChatGPT
                launchChatGPT()
            }
        }
    }

    private fun launchChatGPT() {
        try {
            val packageManager = packageManager
            val launchIntent = packageManager.getLaunchIntentForPackage(CHATGPT_PACKAGE)
            
            if (launchIntent != null) {
                // Add flags to start a new instance or bring to front
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                // Add deep link to start ChatGPT 4.0 directly
                launchIntent.data = Uri.parse("chatgpt://chat?model=gpt-4")
                startActivity(launchIntent)
            } else {
                // ChatGPT not installed, open Play Store
                val playStoreIntent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("market://details?id=$CHATGPT_PACKAGE")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(playStoreIntent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error launching ChatGPT: ${e.message}")
        }
    }

    private fun stopChatGPT() {
        // This is a simplified approach - in a real app, you might use ActivityManager
        // or Android's app usage stats to determine if ChatGPT is running
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(homeIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping ChatGPT: ${e.message}")
        }
    }
}