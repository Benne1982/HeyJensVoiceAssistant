package com.assistant.heyjens.util

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import kotlin.random.Random

class WakewordDetectorTest {

    private lateinit var wakewordDetector: WakewordDetector
    
    @Before
    fun setup() {
        wakewordDetector = WakewordDetector("hey jens")
    }
    
    @Test
    fun `test low energy audio does not trigger detection`() {
        // Create a buffer with low energy values
        val buffer = ShortArray(1024) { 10.toShort() }
        
        // Should not detect wakeword in low energy audio
        assertFalse(wakewordDetector.detect(buffer, buffer.size))
    }
    
    @Test
    fun `test high energy audio can trigger detection`() {
        // Create a buffer with high energy values
        val buffer = ShortArray(1024) { 3000.toShort() }
        
        // Should potentially detect wakeword in high energy audio
        // Note: This is a simplified test for our simplified detector
        val result = wakewordDetector.detect(buffer, buffer.size)
        
        // The first detection might be true or false depending on implementation details
        // We're just testing the basic functionality here
        if (!result) {
            // If first call didn't detect, try a few more times to simulate consecutive frames
            var detected = false
            for (i in 0 until 10) {
                if (wakewordDetector.detect(buffer, buffer.size)) {
                    detected = true
                    break
                }
            }
            assertTrue("High energy audio should eventually trigger detection", detected)
        }
    }
    
    @Test
    fun `test cooldown period prevents immediate re-detection`() {
        // Create a buffer with high energy values
        val buffer = ShortArray(1024) { 3000.toShort() }
        
        // Trigger initial detection (may take multiple calls)
        var initialDetection = false
        for (i in 0 until 10) {
            if (wakewordDetector.detect(buffer, buffer.size)) {
                initialDetection = true
                break
            }
        }
        
        // If we got an initial detection, verify cooldown works
        if (initialDetection) {
            // Immediate attempt should fail due to cooldown
            assertFalse(wakewordDetector.detect(buffer, buffer.size))
        }
    }
    
    @Test
    fun `test reset clears detector state`() {
        // Create a buffer with high energy values
        val buffer = ShortArray(1024) { 3000.toShort() }
        
        // Potentially trigger detection
        for (i in 0 until 10) {
            wakewordDetector.detect(buffer, buffer.size)
        }
        
        // Reset the detector
        wakewordDetector.reset()
        
        // Create a low energy buffer that shouldn't trigger detection
        val lowBuffer = ShortArray(1024) { 10.toShort() }
        assertFalse(wakewordDetector.detect(lowBuffer, lowBuffer.size))
    }
}