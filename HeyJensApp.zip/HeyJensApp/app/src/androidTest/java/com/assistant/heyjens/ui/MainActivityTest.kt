package com.assistant.heyjens.ui

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.assistant.heyjens.R
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainActivityTest {

    @get:Rule
    val activityRule = ActivityScenarioRule(MainActivity::class.java)

    @Test
    fun testUIElementsDisplayed() {
        // Verify all UI elements are displayed
        onView(withId(R.id.tvTitle)).check(matches(isDisplayed()))
        onView(withId(R.id.ivMic)).check(matches(isDisplayed()))
        onView(withId(R.id.tvInstructions)).check(matches(isDisplayed()))
        onView(withId(R.id.tvStatus)).check(matches(isDisplayed()))
        onView(withId(R.id.btnStartService)).check(matches(isDisplayed()))
        onView(withId(R.id.btnStopService)).check(matches(isDisplayed()))
        onView(withId(R.id.btnBatteryOptimization)).check(matches(isDisplayed()))
    }

    @Test
    fun testStartButtonInitiallyEnabled() {
        // Verify start button is initially enabled
        onView(withId(R.id.btnStartService)).check(matches(isEnabled()))
    }

    @Test
    fun testStopButtonInitiallyDisabled() {
        // Verify stop button is initially disabled
        onView(withId(R.id.btnStopService)).check(matches(not(isEnabled())))
    }

    // Note: More comprehensive tests would include permission handling,
    // service interaction, and state changes, but those require more complex setup
}